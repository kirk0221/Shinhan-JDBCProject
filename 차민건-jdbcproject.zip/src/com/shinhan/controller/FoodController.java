package com.shinhan.controller;

import java.util.List;

import com.shinhan.common.CommonControllerInterface;
import com.shinhan.dto.FoodDTO;
import com.shinhan.dto.RatingDTO;
import com.shinhan.dto.UsersDTO;
import com.shinhan.service.FoodService;
import com.shinhan.service.RatingService;
import com.shinhan.utils.InsertUtil;
import com.shinhan.utils.ScannerUtil;
import com.shinhan.view.CommonView;
import com.shinhan.view.FoodView;

public class FoodController implements CommonControllerInterface {

	String job_name = "식품";
	UsersDTO user = null;
	FoodService foodService = new FoodService();
	RatingService ratingService = new RatingService();
	
	@Override
	public void execute() {
		int select;
		boolean is_end = false;
		while(!is_end) {
			FoodView.displaymenu(user.getIs_vulnerable());
			select = InsertUtil.check_Integer_Input("번호 입력 > ");
			switch(select) {
			case 1 -> {
				f_selectAll();
			}
			case 2 ->{
				f_selectAllAvailableSharing();
			}
			case 3 ->{
				f_selectByName();
			}
			case 4 ->{
				f_foodShared_foodInsert();
			}
			case 5 ->{
				f_foodUpdate_ratingInsert();
			}
			case 6 ->{
				f_foodDelete_ratingDelete();
			}
			case 99 ->{
				is_end = true;
			}
			default ->{
				CommonView.display_ready();
			}
			
			}
		}
		CommonView.goodBye(job_name);
	}

	private void f_foodDelete_ratingDelete() {
		int result = 0;
		FoodDTO food = null;
		String message = "잘못된 정보를 입력하였습니다.";
		if(user.getIs_vulnerable()) {
			List<RatingDTO> rating_list = ratingService.selectById(user);
			if (checkAndDisplayList(rating_list)) {
				int rating_id = InsertUtil.check_Integer_Input("삭제할 평점의 id 입력 > ");
				result = ratingService.ratingDelete(rating_id);
				if(result != 0) {
					message = result + " 개의 평점을 삭제했습니다";
				}
			}
		}
		else {
			List<FoodDTO> food_list = foodService.selectByUserID(user);
			if (checkAndDisplayList(food_list)){
				food = foodSelectById();
				if (food == null) {
				    CommonView.display("선택한 음식이 존재하지 않습니다.");
				    return;
				}
				result = foodService.foodDelete(food);
				if(result != 0) {
					message = result + " 개의 음식을 삭제했습니다";
				}
			}
		}
		CommonView.display(message);
	}

	private void f_foodUpdate_ratingInsert() {
		int result = 0;
		FoodDTO food = null;
		String message = "잘못된 정보를 입력하였습니다.";
		if(user.getIs_vulnerable()) {
			List<FoodDTO> food_list = foodService.getRecievedFoodList(user);
			if(checkAndDisplayList(food_list)) {
				int food_id = InsertUtil.check_Integer_Input("평점을 남길 음식 id 입력 > ");
				RatingDTO rating = ratingService.makeRating();
				result = ratingService.ratingInsert(rating, food_id, user);
				if(result != 0) {
					message = result + " 개의 평점을 남겼습니다.";
				}
			}
		}
		else{
			List<FoodDTO> food_list = foodService.selectByUserID(user);
			if(checkAndDisplayList(food_list)){
				int food_id = InsertUtil.check_Integer_Input("수정하고싶은 음식 id 입력 > ");
				food = foodService.makeFoodDTO(user);
				result = foodService.foodUpdate(food_id, food);
				if(result != 0) {
					message = result + " 개의 음식을 수정했습니다.";
				}
			}
			CommonView.display(message);
		}
	}

	private void f_foodShared_foodInsert() {
		int result = 0;
		FoodDTO food = null;
		String message = "잘못된 정보를 입력하였습니다.";
		if(user.getIs_vulnerable()) {
			f_selectAllAvailableSharing();
			List<FoodDTO> food_list = getFoodDTOByName();
			if(checkAndDisplayList(food_list)) {
				food = foodSelectById();
				if (food != null && food.getIs_sharing()) {
					result = foodService.foodShared(food, user);
				}
			}
		}else {
			food = foodService.makeFoodDTO(user);
			result = foodService.foodInsert(food);
			
		}
		if(result != 0) {
			String str_result = user.getIs_vulnerable()?"기부받았습니다.":"등록했습니다.";
			message = result + " 개의 음식을 " + str_result;
		}
		CommonView.display(message);
	}
	
	private FoodDTO foodSelectById() {
		int food_id = InsertUtil.check_Integer_Input("음식 id 선택 > ");
		return foodService.selectById(food_id);
	}

	private void f_selectByName() {
		List<FoodDTO> food = getFoodDTOByName();
		CommonView.display(food, job_name);
	}
	
	private List<FoodDTO> getFoodDTOByName() {
		System.out.print("음식명 > ");
		String foodName =ScannerUtil.sc.nextLine();
		return foodService.selectByName(foodName);
	}

	private void f_selectAllAvailableSharing() {
		List<FoodDTO> foodlist = foodService.selectAllAvailableSharing();
		CommonView.display(foodlist, job_name);
	}

	private void f_selectAll() {
		List<FoodDTO> foodlist = foodService.selectAll();
		CommonView.display(foodlist, job_name);
	}
	
	@Override
	public boolean checkAndDisplayList(List<?> list) {
	    if (list == null || list.isEmpty()) {
	        CommonView.display("조회된 음식이 없습니다.");
	        return false;
	    }
	    CommonView.display(list, job_name);
	    return true;
	}


	@Override
	public void getUser(UsersDTO user) {
		this.user = user;
		
	}

}
