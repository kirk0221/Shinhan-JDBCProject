package com.shinhan.controller;

import java.util.List;

import com.shinhan.common.CommonControllerInterface;
import com.shinhan.dto.ReportDTO;
import com.shinhan.dto.UsersDTO;
import com.shinhan.service.ReportService;
import com.shinhan.service.UsersService;
import com.shinhan.utils.InsertUtil;
import com.shinhan.utils.ScannerUtil;
import com.shinhan.view.CommonView;
import com.shinhan.view.ReportView;

public class ReportController implements CommonControllerInterface {

	String job_name = "신고";
	UsersDTO user = null;
	ReportService reportService = new ReportService();
	UsersService usersService = new UsersService();
	
	@Override
	public void execute() {
		int select;
		boolean is_end = false;
		while(!is_end) {
			ReportView.displaymenu();
			select = InsertUtil.check_Integer_Input("번호 입력 > ");
			switch (select) {
			case 1->{
				f_selectByReport();
			}
			case 2->{
				f_selectByReported();
			}
			case 3->{
				f_reportInsert();
			}
			case 4->{
				f_reportUpdate();
			}
			case 5->{
				f_reportDelete();
			}
			case 99 ->{
				is_end = true;
			}
			default ->{
				CommonView.display_ready();
			}
			}
		}
		CommonView.goodBye(job_name);
	}

	private void f_reportDelete() {
		int result = 0;
		String message = "잘못된 정보를 입력하였습니다.";
		if (f_selectByReport()) {
			List<UsersDTO> userlist = usersService.selectToUserIdAndID();
			checkAndDisplayList_foruseridandid(userlist);
			int reportId = InsertUtil.check_Integer_Input("삭제하고 싶은 신고 id 입력 > ");
			result = reportService.reportDelete(reportId);
			if(result != 0) {
				message = result + " 개의 신고를 삭제하였습니다.";
			}
		}
		CommonView.display(message);
	}

	private void f_reportUpdate() {
		int result = 0;
		String message = "잘못된 정보를 입력하였습니다.";
		if (f_selectByReport()) {
			List<UsersDTO> userlist = usersService.selectToUserIdAndID();
			checkAndDisplayList_foruseridandid(userlist);
			int reportId = InsertUtil.check_Integer_Input("수정하고 싶은 신고 id 입력 > ");
			ReportDTO reportDTO = makeReportDTO();
			result = reportService.reportUpdate(reportId, reportDTO);
			if(result != 0) {
				message = result + " 개의 신고를 수정하였습니다.";
			}
		}
		CommonView.display(message);
	}

	private void f_reportInsert() {
		List<UsersDTO> userlist = usersService.selectToUserIdAndID();
		checkAndDisplayList_foruseridandid(userlist);
		
		int result = 0;
		String message = "잘못된 정보를 입력하였습니다.";
		ReportDTO reportDTO = makeReportDTO();
		result = reportService.reportInsert(reportDTO, user);
		if(result != 0) {
			message = result + " 개의 신고를 성공하였습니다.";
		}
		CommonView.display(message);
	}

	private ReportDTO makeReportDTO() {
		Integer reported_user_id = InsertUtil.check_Integer_Input("신고할 user_id(필수 입력) > ");
		System.out.println("0 입력시 null값 입력됩니다.");
		System.out.print("신고 내용 > ");
		String reason = ScannerUtil.sc.nextLine();
		if(reason.equals("0")) reason = null;
		
		ReportDTO reportDTO = ReportDTO.builder()
				.reported_user_id(reported_user_id)
				.reason(reason)
				.build();
		return reportDTO;
	}

	private boolean f_selectByReported() {
		List<ReportDTO> reportlist = reportService.selectByReportedUserID(user);
		if (checkAndDisplayList(reportlist)) return true;
		return false;
	}

	private boolean f_selectByReport() {
		List<ReportDTO> reportlist = reportService.selectByReportUserID(user);
		if (checkAndDisplayList(reportlist)) return true;
		return false;
	}

	@Override
	public void getUser(UsersDTO user) {
		this.user = user;
	}

	@Override
	public boolean checkAndDisplayList(List<?> list) {
	    if (list == null || list.isEmpty()) {
	        CommonView.display("조회된 신고가 없습니다.");
	        return false;
	    }
	    CommonView.display(list, job_name);
	    return true;
	}
	
	public boolean checkAndDisplayList_foruseridandid(List<UsersDTO> list) {
		if (list == null || list.isEmpty()) {
			CommonView.display("조회된 신고가 없습니다.");
			return false;
		}
		ReportView.displayUserIDandID(list);
		return true;
	}

}
