package com.shinhan.controller;

import com.shinhan.dto.UsersDTO;
import com.shinhan.service.UsersService;
import com.shinhan.utils.InsertUtil;
import com.shinhan.view.CommonView;

public class LoginController {

	UsersService loginService = new UsersService();
	UsersDTO user = null;
	
	public void joinMembership() {
		user = Membership_registration();
		String message = "회원 가입 실패";
		if (user != null) {
			int result = loginService.Membership_registration(user);
	        if (result > 0) {
	            message = "회원 가입 완료";
	        }
		}
		CommonView.display(message);
	}
	
	public void login() {
		String id = InsertUtil.check_String_Input("id 입력 > ");
		String password = InsertUtil.check_String_Input("password 입력 > ");
		String message = "로그인 실패";
		user = loginService.login(id, password);
		if (user != null) {
			message = "로그인 완료";
		}
		CommonView.display(message);
	}
	
	private UsersDTO Membership_registration() {
		boolean is_vulnerable = false;
		String id = InsertUtil.check_String_Input("id 입력 > ");
		String password = InsertUtil.check_String_Input("password 입력 > ");
		String name = InsertUtil.check_String_Input("이름 입력 > ");
		String phone_number = InsertUtil.check_PhoneNumber_Input("전화번호 입력(010-####-####) > ");
		String address = InsertUtil.check_String_Input("주소 입력 > ");
		int user_is_vulnerable = InsertUtil.check_Integer_Input("취약 계층 여부 입력 (취약 계층일 경우 1) > ");
		if (user_is_vulnerable == 1) {
			is_vulnerable = true;
		}
		
		UsersDTO usersDTO = UsersDTO.builder()
				.id(id)
				.password(password)
				.name(name)
				.phone_number(phone_number)
				.address(address)
				.is_vulnerable(is_vulnerable)
				.point(0)
				.badge("없음")
				.build();
		return usersDTO;
	}
	
	public String helloUser() {
		if(user.getIs_vulnerable())return user.getId() + "님 접속을 환영합니다."; 
		else return user.getBadge() + " 등급 " + user.getId() + "님 접속을 환영합니다.";
	}

	public UsersDTO getUser() {
		return user;
	}
	
}
