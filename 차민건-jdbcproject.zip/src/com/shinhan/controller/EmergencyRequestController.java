package com.shinhan.controller;

import java.util.List;

import com.shinhan.common.CommonControllerInterface;
import com.shinhan.dto.EmergencyRequestDTO;
import com.shinhan.dto.FoodDTO;
import com.shinhan.dto.UsersDTO;
import com.shinhan.service.EmergencyRequestService;
import com.shinhan.service.FoodService;
import com.shinhan.utils.InsertUtil;
import com.shinhan.view.CommonView;
import com.shinhan.view.EmergencyRequestView;

public class EmergencyRequestController implements CommonControllerInterface {

	String job_name = "긴급 요청";
	UsersDTO user = null;
	EmergencyRequestService emergencyRequestService = new EmergencyRequestService();
	FoodService foodService = new FoodService();
	
	@Override
	public void execute() {
		int select;
		boolean is_end = false;
		while (!is_end) {
			EmergencyRequestView.displaymenu(user.getIs_vulnerable());
			select = InsertUtil.check_Integer_Input("번호 입력 > ");
			switch (select) {
			case 1 -> {
				f_selectAll();
			}
			case 2 -> {
				f_selectMyRequest_selectByMyaddress();
			}
			case 3 ->{
				f_requestInsert_foodInsert();
			}
			case 4 ->{
				if(user.getIs_vulnerable()) f_requestUpdate();
				else CommonView.display_ready();
			}
			case 5 ->{
				if(user.getIs_vulnerable()) f_requestDelete();
				else CommonView.display_ready();
			}
			
			case 99 ->{
				is_end = true;
			}
			default -> {
				CommonView.display_ready();
			}
			}
		}
		CommonView.goodBye(job_name);
	}

	private void f_requestDelete() {
		int result;
		String message = "잘못된 정보를 입력하였습니다.";
		if(f_selectMyRequest_selectByMyaddress()) {
			int request_id = InsertUtil.check_Integer_Input("삭제할 request id 선택 > ");
			result = emergencyRequestService.emergencyRequestDelete(request_id);
			if(result != 0) {
				message = result + "개의 긴급 요청을 삭제했습니다.";
			}
		}
		CommonView.display(message);
	}

	private void f_requestUpdate() {
		int result;
		String message = "잘못된 정보를 입력하였습니다.";
		if(f_selectMyRequest_selectByMyaddress()) {
			int request_id = InsertUtil.check_Integer_Input("수정할 request id 선택 > ");
			EmergencyRequestDTO emergencyRequestDTO = emergencyRequestService.makeEmergencyRequestDTO();
			result = emergencyRequestService.emergencyRequestUpdate(request_id, emergencyRequestDTO);
			if(result != 0) {
				message = result + "개의 긴급 요청을 수정했습니다.";
			}
		}
		CommonView.display(message);
	}

	private void f_requestInsert_foodInsert() {
		int result;
		String message = "잘못된 정보를 입력하였습니다.";
		if(user.getIs_vulnerable()) {
			EmergencyRequestDTO emergencyRequestDTO = emergencyRequestService.makeEmergencyRequestDTO();
			result = emergencyRequestService.emergencyRequestInsert(user, emergencyRequestDTO);
			if(result != 0) {
				message = result + "개의 긴급 요청을 등록했습니다.";
			}
		}else {
			FoodDTO food = foodService.makeFoodDTO(user);
			result = foodService.foodInsert(food);
			if(result != 0) {
				message = result + "개의 식품을 등록했습니다.";
			}
		}
		CommonView.display(message);
	}

	private boolean f_selectMyRequest_selectByMyaddress() {
		if(user.getIs_vulnerable()) {
			List<EmergencyRequestDTO> emergencyRequestlist = emergencyRequestService.selectByUserId(user);
			return checkAndDisplayList(emergencyRequestlist);
		}else {
			List<EmergencyRequestDTO> emergencyRequestlist = emergencyRequestService.selectByUserAddress(user);
			return checkAndDisplayList(emergencyRequestlist);
		}
	}

	private void f_selectAll() {
		List<EmergencyRequestDTO> emergencyRequestlist = emergencyRequestService.selectAll();
		checkAndDisplayList(emergencyRequestlist);
	}
	
	@Override
	public boolean checkAndDisplayList(List<?> list) {
	    if (list == null || list.isEmpty()) {
	        CommonView.display("조회된 긴급 요청이 없습니다.");
	        return false;
	    }
	    CommonView.display(list, job_name);
	    return true;
	}

	@Override
	public void getUser(UsersDTO user) {
		this.user = user;
	}

}
