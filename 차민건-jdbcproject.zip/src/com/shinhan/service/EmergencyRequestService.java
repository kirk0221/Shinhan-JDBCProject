package com.shinhan.service;

import java.util.List;

import com.shinhan.dao.EmergencyRequestDAO;
import com.shinhan.dto.EmergencyRequestDTO;
import com.shinhan.dto.UsersDTO;
import com.shinhan.utils.InsertUtil;

public class EmergencyRequestService {
	EmergencyRequestDAO emergencyRequestDAO = new EmergencyRequestDAO();
	
	public  List<EmergencyRequestDTO> selectAll(){
		return emergencyRequestDAO.selectAll();
	}
	public List<EmergencyRequestDTO> selectByUserId(UsersDTO user){
		return emergencyRequestDAO.selectByUserId(user);
	}
	public List<EmergencyRequestDTO> selectByUserAddress(UsersDTO user){
		return emergencyRequestDAO.selectByUserAddress(user);
	}
	public int emergencyRequestInsert(UsersDTO user, EmergencyRequestDTO emergencyRequestDTO) {
		return emergencyRequestDAO.emergencyRequestInsert(user, emergencyRequestDTO);
	}
	public int emergencyRequestUpdate(int request_id, EmergencyRequestDTO emergencyRequest) {
		return emergencyRequestDAO.emergencyRequestUpdate(request_id, emergencyRequest);
	}
	public int emergencyRequestDelete(int request_id) {
		return emergencyRequestDAO.emergencyRequestDelete(request_id);
	}
	
	public EmergencyRequestDTO makeEmergencyRequestDTO() {
		System.out.println("※ 값이 없으면 '0'을 입력하세요 (→ null 처리됨)");
		String food_name = InsertUtil.check_String_Input("요청 식품명(필수 입력) > ");
		String place = InsertUtil.check_String_Input("요청 장소 > ");
		String detail = InsertUtil.check_String_Input("요청 상세 내용 > ");
		if(place.trim().equals("0")) place = null;
		if(detail.trim().equals("0")) detail = null;
		
		EmergencyRequestDTO emergencyRequestDTO = EmergencyRequestDTO.builder()
				.food_name(food_name)
				.place(place)
				.detail(detail)
				.build();
		
		return emergencyRequestDTO;
	}

}
