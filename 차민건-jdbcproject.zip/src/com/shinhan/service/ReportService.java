package com.shinhan.service;

import java.util.List;

import com.shinhan.dao.ReportDAO;
import com.shinhan.dto.ReportDTO;
import com.shinhan.dto.UsersDTO;

public class ReportService {
	
	ReportDAO reportDAO = new ReportDAO();
	
	public int reportDelete(int reportId) {
		return reportDAO.reportDelete(reportId);
	}
	
	public int reportUpdate(int reportId, ReportDTO report) {
		return reportDAO.reportUpdate(reportId, report);
	}
	
	public int reportInsert(ReportDTO report, UsersDTO user) {
		return reportDAO.reportInsert(report, user);
	}
	
	public List<ReportDTO> selectByReportUserID(UsersDTO user){
		return reportDAO.selectByReportUserID(user);
	}
	
	public List<ReportDTO> selectByReportedUserID(UsersDTO user){
		return reportDAO.selectByReportedUserID(user);
	}
}
