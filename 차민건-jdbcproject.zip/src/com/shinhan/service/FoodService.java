package com.shinhan.service;

import java.sql.Date;
import java.util.List;

import com.shinhan.dao.FoodDAO;
import com.shinhan.dto.FoodDTO;
import com.shinhan.dto.UsersDTO;
import com.shinhan.utils.InsertUtil;

public class FoodService {

	FoodDAO foodDAO = new FoodDAO();

	public List<FoodDTO> selectAll() {
		return foodDAO.selectAll();
	}

	public List<FoodDTO> selectAllAvailableSharing() {
		return foodDAO.selectAllAvailableSharing();
	}

	public List<FoodDTO> selectByName(String foodName) {
		return foodDAO.selectByName(foodName);
	}

	public List<FoodDTO> selectByName(String foodName, UsersDTO user) {
		return foodDAO.selectByName(foodName, user);
	}

	public int foodShared(FoodDTO food, UsersDTO user) {
		return foodDAO.foodShared(food, user);
	}

	public int foodInsert(FoodDTO food) {
		return foodDAO.foodInsert(food);
	}

	public int foodUpdate(int food_id, FoodDTO food) {
		return foodDAO.foodUpdate(food_id, food);
	}

	public int foodDelete(FoodDTO food) {
		return foodDAO.foodDelete(food);
	}

	public FoodDTO selectById(int foodId) {
		return foodDAO.selectById(foodId);
	}

	public List<FoodDTO> getRecievedFoodList(UsersDTO user) {
		return foodDAO.getRecievedFoodList(user);
	}

	public List<FoodDTO> selectByUserID(UsersDTO user) {
		return foodDAO.selectByUserID(user);
	}

	public FoodDTO makeFoodDTO(UsersDTO user) {
		System.out.println("※ 값이 없으면 '0'을 입력하세요 (→ null 처리됨)");
		String name = InsertUtil.check_String_Input("식품명(필수 입력) > ");
		Date expiration_date = InsertUtil.check_Date_Input("유통기한 (yyyy-MM-dd) > ");
		String place = InsertUtil.check_String_Input("나눔 장소 > ");
		Integer amount = InsertUtil.check_Integer_Input("식품 수량 > ");
		if (place.trim().equals("0"))
			place = null;
		if (amount.equals("0"))
			amount = null;
		FoodDTO foodDTO = FoodDTO.builder().giver_id(user.getUser_id()).name(name).expiration_date(expiration_date)
				.place(place).amount(amount).build();
		return foodDTO;
	}
}
