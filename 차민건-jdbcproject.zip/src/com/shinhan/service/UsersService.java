package com.shinhan.service;

import java.util.List;

import com.shinhan.dao.UsersDAO;
import com.shinhan.dto.UsersDTO;

public class UsersService {
	
	UsersDAO users = new UsersDAO();

	public int Membership_registration(UsersDTO user){
		return users.Membership_registration(user);
	}
	public UsersDTO login(String id, String password) {
		return users.login(id, password);
	}
	public List<UsersDTO> selectToUserIdAndID(){
		return users.selectToUserIdAndID();
	}

}
