package com.shinhan.service;

import java.util.List;

import com.shinhan.dao.RatingDAO;
import com.shinhan.dto.RatingDTO;
import com.shinhan.dto.UsersDTO;
import com.shinhan.utils.InsertUtil;

public class RatingService {
	RatingDAO ratingDAO = new RatingDAO();
	public int ratingInsert(RatingDTO rating, int foodId, UsersDTO user) {
		return ratingDAO.ratingInsert(rating, foodId, user);
	}
	
	public List<RatingDTO> selectById(UsersDTO user){
		return ratingDAO.selectById(user);
	}
	
	public int ratingDelete(int rating_id) {
		return ratingDAO.ratingDelete(rating_id);
	}
	
	public RatingDTO makeRating() {
		System.out.println("※ 값이 없으면 '0'을 입력하세요 (→ null 처리됨)");
		Integer score = InsertUtil.check_Integer_Input("점수(0~10) > ");
		boolean damage_check = (InsertUtil.check_Integer_Input("손상 여부(손상되었으면 1) > ") == 1);
		String user_comment = InsertUtil.check_String_Input("상세 내용 > ");
		if(score.equals("0")) score = null;
		if(user_comment.trim().equals("0")) user_comment = null;
		
		RatingDTO ratingDTO = RatingDTO.builder()
				.score(score)
				.damage_check(damage_check)
				.user_comment(user_comment)
				.build();
		return ratingDTO;
	}
	
}
