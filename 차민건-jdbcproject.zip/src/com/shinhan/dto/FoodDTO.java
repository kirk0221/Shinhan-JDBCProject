package com.shinhan.dto;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FoodDTO extends DTOParent {
	 private Integer food_id;
	 private Integer giver_id;
	 private String name;
	 private Date expiration_date;
	 private Date registration_date;
	 private String place;
	 private Integer amount;
	 private Boolean is_sharing;
}
