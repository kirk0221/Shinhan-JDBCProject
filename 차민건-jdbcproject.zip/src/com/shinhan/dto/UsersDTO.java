package com.shinhan.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UsersDTO extends DTOParent {
	private Integer user_id;
	private String id;
	private String password;
	private String name;
	private String phone_number;
	private String address;
	private Boolean is_vulnerable;
	private Integer point;
	private String badge;
	
	public String get_userid_and_id() {
		return "UsersDTO(user_id="+user_id+", id="+id+")";
	}
}
