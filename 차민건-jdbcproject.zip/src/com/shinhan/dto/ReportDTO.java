package com.shinhan.dto;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ReportDTO extends DTOParent {
	private Integer report_id;
	private Integer report_user_id;
	private Integer reported_user_id;
	private String reason;
	private Date report_date;
}
