package com.shinhan.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RatingDTO extends DTOParent {
	private Integer rating_id;
	private Integer writer_id;
	private Integer food_id;
	private Integer score;
	private Boolean damage_check;
	private String user_comment;
}
