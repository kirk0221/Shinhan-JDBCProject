package com.shinhan.dto;

public abstract class DTOParent {

}
