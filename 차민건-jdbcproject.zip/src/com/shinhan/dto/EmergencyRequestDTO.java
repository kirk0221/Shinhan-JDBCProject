package com.shinhan.dto;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EmergencyRequestDTO extends DTOParent {
	private Integer request_id;
	private Integer receiver_id;
	private String food_name;
	private String place;
	private String detail;
	private Date request_date;
}
