package com.shinhan.dto;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SharingDTO extends DTOParent {
	private Integer sharing_id;
	private Integer food_id;
	private Integer receiver_id;
	private Date sharing_date;
}
