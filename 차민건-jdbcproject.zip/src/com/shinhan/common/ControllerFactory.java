package com.shinhan.common;

import com.shinhan.controller.EmergencyRequestController;
import com.shinhan.controller.FoodController;
import com.shinhan.controller.ReportController;

// Factory Pattern
public class ControllerFactory {

	public static CommonControllerInterface make(String business) {
		CommonControllerInterface commonControllerInterface = null;
		switch (business) {
		case ("food") -> commonControllerInterface = new FoodController();
		case ("emergencyRequest") -> commonControllerInterface = new EmergencyRequestController();
		case ("report") -> commonControllerInterface = new ReportController();
		}
		return commonControllerInterface;
	}

}
