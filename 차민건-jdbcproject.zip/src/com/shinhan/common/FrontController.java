package com.shinhan.common;

import com.shinhan.controller.EmergencyRequestController;
import com.shinhan.controller.FoodController;
import com.shinhan.controller.LoginController;
import com.shinhan.controller.ReportController;
import com.shinhan.dto.UsersDTO;
import com.shinhan.utils.InsertUtil;
import com.shinhan.utils.ScannerUtil;
import com.shinhan.view.CommonView;

public class FrontController {

	public static void main(String[] args) {
		boolean is_login = false;
		boolean is_end = false;
		CommonControllerInterface commonControllerInterface = null;
		LoginController loginController = new LoginController();
		UsersDTO user = null;
		int select;
		while (!is_login && !is_end) {
			CommonView.displaymenuBeforeLogin();
			select = InsertUtil.check_Integer_Input("번호 입력 > ");
			switch (select) {
			case 1 -> {
				loginController.login();
				user = loginController.getUser();
				if (user != null) {
					CommonView.display(loginController.helloUser());
					is_login = true;
					continue;
				}
				continue;
			}
			case 2 -> {
				loginController.joinMembership();
			}
			case 3 -> {
				is_end = true;
				continue;
			}
			default -> {
				CommonView.display_ready();
			}
			}
		}
		while (is_login && !is_end) {
			CommonView.displaymenuAfterLogin();
			select = InsertUtil.check_Integer_Input("번호 입력 > ");
			switch (select) {
			case 1 -> {
				commonControllerInterface = ControllerFactory.make("food");
			}
			case 2 -> {
				commonControllerInterface = ControllerFactory.make("emergencyRequest");
			}
			case 3 -> {
				commonControllerInterface = ControllerFactory.make("report");
			}
			case 99 -> {
				is_end = true;
				continue;
			}
			default -> {
				CommonView.display_ready();
			}
			}
			if(commonControllerInterface != null) {
				commonControllerInterface.getUser(user);
				commonControllerInterface.execute();
			}
		}
		ScannerUtil.sc.close();
		CommonView.goodBye();
	}
}
