package com.shinhan.common;

import java.util.List;

import com.shinhan.dto.UsersDTO;

public interface CommonControllerInterface {
	String job_name = "";
	public abstract void execute();
	public abstract boolean checkAndDisplayList(List<?> list);
	public abstract void getUser(UsersDTO user);
}
