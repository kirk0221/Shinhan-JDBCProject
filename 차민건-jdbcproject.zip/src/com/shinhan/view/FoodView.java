package com.shinhan.view;

public class FoodView {

	public static void displaymenu(Boolean IsVulnerable) {
		String menu = IsVulnerable ? displaymenu_vulnerable() : displaymenu_common();
		System.out.println("------------------------------------------------------------------");
		System.out.println("1. 조회(식품 전체) 2. 조회(나눔 가능) 3. 조회(식품 이름) " + menu + " 99. 종료");
		System.out.println("------------------------------------------------------------------");
	}

	private static String displaymenu_common() {
		return "4. 식품 등록 5. 식품 수정 6. 식품 삭제";
	}

	private static String displaymenu_vulnerable() {
		return "4. 식품 나눔 받기 5. 평점 작성 6. 평점 삭제";
	}

}
