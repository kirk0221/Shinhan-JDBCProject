package com.shinhan.view;

import java.util.List;

import com.shinhan.dto.DTOParent;

public class CommonView {

	public static void display(String message) {
		System.out.println("알림 > " + message);
	}

	public static void displaymenuBeforeLogin() {
		System.out.println("----------------------------------------------------------------");
		System.out.println("1. 로그인 2. 회원 가입 3. 종료");
		System.out.println("----------------------------------------------------------------");
	}

	public static void displaymenuAfterLogin() {
		System.out.println("----------------------------------------------------------------");
		System.out.println("1. 음식 기부 2. 음식 요청 3. 신고 99. 종료");
		System.out.println("----------------------------------------------------------------");
	}

	public static void goodBye() {
		System.out.println("=========    ====    =========");
		System.out.println("========  ===    ===  ========");
		System.out.println("=======   Good Bye!!!  =======");
		System.out.println("========  ==========  ========");
		System.out.println("==========  ======  ==========");
		System.out.println("============  ==  ============");
		System.out.println("==============   =============");
	}

	public static void goodBye(String message) {
		System.out.println("=========" + message + " 게시판 종료=========");
	}

	public static void display_ready() {
		display("서비스 준비중입니다.");
	}

	public static void display(List<?> list, String message) {
		if (list.size() == 0) {
			CommonView.display("해당하는 데이터가 존재하지 않습니다.");
			return;
		}
		System.out.println("=====" + message + " 여러건 조회=====");
		list.stream().forEach(dto -> System.out.println(dto));
	}

	public static void display(DTOParent dto, String message) {
		if (dto == null) {
			CommonView.display("해당하는 데이터가 존재하지 않습니다.");
			return;
		}
		System.out.println("=====" + message + " 정보 조회=====");
		System.out.println(dto);
	}

}
