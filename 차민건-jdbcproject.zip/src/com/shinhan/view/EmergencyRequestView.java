package com.shinhan.view;

public class EmergencyRequestView {

	public static void displaymenu(Boolean IsVulnerable) {
		String menu = IsVulnerable ? displaymenu_vulnerable() : displaymenu_common();
		System.out.println("---------------------------------------------------------------------------");
		System.out.println("1. 조회(요청 전체) "+menu+" 99. 종료");
		System.out.println("---------------------------------------------------------------------------");
	}

	private static String displaymenu_common() {
		return "2. 조회(내 지역) 3. 음식 등록";
	}

	private static String displaymenu_vulnerable() {
		return "2. 조회(내 요청) 3. 긴급 요청 등록 4. 긴급 요청 수정 5. 긴급 요청 삭제";
	}
}
