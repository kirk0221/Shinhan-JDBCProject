package com.shinhan.view;

import java.util.List;

import com.shinhan.dto.UsersDTO;

public class ReportView {

	public static void displaymenu() {
		System.out.println("---------------------------------------------------------------------------");
		System.out.println("1. 조회(내가 한 신고) 2. 조회(내가 받은 신고) 3. 신고 등록 4. 신고 수정 5. 신고 삭제 99. 종료");
		System.out.println("---------------------------------------------------------------------------");
	}

	public static void displayUserIDandID(List<UsersDTO> list) {
		if (list.size() == 0) {
			CommonView.display("해당하는 데이터가 존재하지 않습니다.");
			return;
		}
		System.out.println("=====사용자 정보 여러건 조회=====");
		list.stream().forEach(user -> System.out.println(user.get_userid_and_id()));
	}
}
