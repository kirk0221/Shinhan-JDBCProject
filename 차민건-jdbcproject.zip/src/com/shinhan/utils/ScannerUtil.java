package com.shinhan.utils;

import java.util.Scanner;

public class ScannerUtil {
    public static final Scanner sc = new Scanner(System.in);
}
