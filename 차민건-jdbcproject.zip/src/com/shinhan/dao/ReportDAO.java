package com.shinhan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shinhan.dto.ReportDTO;
import com.shinhan.dto.UsersDTO;
import com.shinhan.utils.DBUtil;

public class ReportDAO {
	
	public int reportDelete(int reportId) {
		int result = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		String sql = "delete from report where report_id = ?";
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, reportId);
			result = st.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
		}
		
		return result;
	}
	
	public int reportUpdate(int reportId, ReportDTO report) {
		int result = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		Map<String, Object> dynamicSQL = new HashMap<>();
		
		if(report.getReported_user_id()!=null) dynamicSQL.put("REPORTED_USER_ID", report.getReported_user_id());
		if(report.getReason()!=null) dynamicSQL.put("REASON", report.getReason());
		
		String sql = "update report set ";
		String sql2 = "where report_id = ?";
		int col = 1, colCount = dynamicSQL.size();
		for(String key: dynamicSQL.keySet()) {
			sql += key + "=" + "?" + (col!=colCount?",":"");
			col++;
		}
		sql += sql2;
		try {
			st = conn.prepareStatement(sql);
			int i=1;
			// 동적으로 값을 할당
			for(String key: dynamicSQL.keySet()) {
				st.setObject(i++, dynamicSQL.get(key));
			}
			st.setInt(i++, reportId);
			result = st.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
		}
		return result;
	}
	
	public int reportInsert(ReportDTO report, UsersDTO user) {
		int result = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		String sql = """
					insert into report(
					report_user_id,
					reported_user_id,
					reason
					)values(
					?,?,?
					)
					""";
		
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, user.getUser_id());
			st.setInt(2, report.getReported_user_id());
			st.setString(3, report.getReason());
			result = st.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
		}
		
		return result;
	}
	
	public List<ReportDTO> selectByReportedUserID(UsersDTO user){
		List<ReportDTO> reportlist = new ArrayList<ReportDTO>();
		Connection conn =  DBUtil.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = """
					select * from report where reported_user_id = ?
					""";
		
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, user.getUser_id());
			rs = st.executeQuery();
			while(rs.next()) {
				ReportDTO reportDTO = makeReportDTO(rs);
				reportlist.add(reportDTO);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		return reportlist;
	}
	
	public List<ReportDTO> selectByReportUserID(UsersDTO user){
		List<ReportDTO> reportlist = new ArrayList<ReportDTO>();
		Connection conn =  DBUtil.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = """
					select * from report where report_user_id = ?
					""";
		
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, user.getUser_id());
			rs = st.executeQuery();
			while(rs.next()) {
				ReportDTO reportDTO = makeReportDTO(rs);
				reportlist.add(reportDTO);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		return reportlist;
	}
	
	private ReportDTO makeReportDTO(ResultSet rs) throws SQLException {
		ReportDTO reportDTO = ReportDTO.builder()
				.report_id(rs.getInt("report_id"))
				.report_user_id(rs.getInt("report_user_id"))
				.reported_user_id(rs.getInt("reported_user_id"))
				.reason(rs.getString("reason"))
				.report_date(rs.getDate("report_date"))
				.build();
		return reportDTO;
	}
}
