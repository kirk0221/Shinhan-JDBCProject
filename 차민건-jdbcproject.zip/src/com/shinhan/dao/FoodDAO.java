package com.shinhan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shinhan.dto.FoodDTO;
import com.shinhan.dto.UsersDTO;
import com.shinhan.utils.DBUtil;

public class FoodDAO {
	
	public int foodDelete(FoodDTO food) {
		int result = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		String sql = "delete from foods where food_id = ?";
		
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, food.getFood_id());
			result = st.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
		}
		
		return result;
	}
	
	public int foodUpdate(int food_id, FoodDTO food) {
		int result = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		Map<String, Object> dynamicSQL = new HashMap<>();
		
		if(food.getName()!=null) dynamicSQL.put("NAME", food.getName());
		if(food.getExpiration_date()!=null) dynamicSQL.put("EXPIRATION_DATE", food.getExpiration_date());
		if(food.getPlace()!=null) dynamicSQL.put("PLACE", food.getPlace());
		if(food.getAmount()!=null) dynamicSQL.put("AMOUNT", food.getAmount());
		
		String sql = "update foods set ";
		String sql2 = "where food_id = ?";
		int col = 1, colCount = dynamicSQL.size();
		for(String key: dynamicSQL.keySet()) {
			sql += key + "=" + "?" + (col!=colCount?",":"");
			col++;
		}
		sql += sql2;
		
		try {
			st = conn.prepareStatement(sql);
			int i=1;
			// 동적으로 값을 할당
			for(String key: dynamicSQL.keySet()) {
				st.setObject(i++, dynamicSQL.get(key));
			}
			st.setInt(i++, food_id);
			result = st.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
		}
		
		return result;
	}
	
	public int foodShared(FoodDTO food, UsersDTO user) {
		int result = 0;
		int result_foods = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		PreparedStatement st2 = null;
		String sql_foods = """
				update Foods set
				AMOUNT = AMOUNT - 1
				where IS_SHARING = 0 and FOOD_ID = ?
				""";
		String sql_sharing = """
				insert into sharing(
				food_id,
				receiver_id
				)
				values(?,?)
				""";
		try {
	        st = conn.prepareStatement(sql_foods);
	        st.setInt(1, food.getFood_id());
	        result_foods = st.executeUpdate();

	        st2 = conn.prepareStatement(sql_sharing);
	        st2.setInt(1, food.getFood_id());
	        st2.setInt(2, user.getUser_id());
	        result = st2.executeUpdate();

	        if(result_foods != 0 && result != 0) {
	            conn.commit();
	            return result;
	        }

	        conn.rollback();
	        return 0;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
			DBUtil.dbDisconnect(null, st2, null);			
		}
		
		return result;
	}
	
	public int foodInsert(FoodDTO food) {
		int result = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		String sql = """
				insert into foods(
					GIVER_ID,
					NAME,
					EXPIRATION_DATE,
					PLACE,
					AMOUNT)
					values(?,?,?,?,?)
					""";
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, food.getGiver_id());
			st.setString(2, food.getName());
			st.setDate(3, food.getExpiration_date());
			st.setString(4, food.getPlace());
			st.setInt(5, food.getAmount());
			result = st.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
		}
		
		
		return result;
	}

	public List<FoodDTO> selectByName(String foodName) {
		List<FoodDTO> foodlist = new ArrayList<FoodDTO>();
		Connection conn =  DBUtil.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = """
				SELECT 
					    f.food_id,
					    f.giver_id,
					    f.name,
					    f.expiration_date,
					    f.registration_date,
					    f.place,
					    f.amount,
					    f.is_sharing
					FROM 
					    foods f
					JOIN 
					    users u ON f.giver_id = u.user_id
					LEFT JOIN (
					    SELECT 
					        food_id,
					        AVG(score) AS avg_score
					    FROM 
					        rating
					    GROUP BY 
					        food_id
					) r ON f.food_id = r.food_id
					where f.name = ? 
					ORDER BY 
					    NVL(r.avg_score, 5) DESC,
					    f.registration_date DESC
				""";
		try {
			st = conn.prepareStatement(sql);
			st.setString(1, foodName);
			rs = st.executeQuery();
			while(rs.next()) {
				FoodDTO foodDTO = makeFoodDTO(rs);
				foodlist.add(foodDTO);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		return foodlist;
	}
	public List<FoodDTO> selectByName(String foodName, UsersDTO user) {
		List<FoodDTO> foodlist = new ArrayList<FoodDTO>();
		Connection conn =  DBUtil.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = "select * from foods where name = ? and giver_id = ?";
		try {
			st = conn.prepareStatement(sql);
			st.setString(1, foodName);
			st.setInt(2, user.getUser_id());
			rs = st.executeQuery();
			while(rs.next()) {
				FoodDTO foodDTO = makeFoodDTO(rs);
				foodlist.add(foodDTO);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		return foodlist;
	}
	
	public List<FoodDTO> selectByUserID(UsersDTO user) {
		List<FoodDTO> foodlist = new ArrayList<FoodDTO>();
		Connection conn =  DBUtil.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = "select * from foods where giver_id = ?";
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, user.getUser_id());
			rs = st.executeQuery();
			while(rs.next()) {
				FoodDTO foodDTO = makeFoodDTO(rs);
				foodlist.add(foodDTO);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		return foodlist;
	}
	
	public FoodDTO selectById(int foodId) {
		FoodDTO foodDTO = null;
		Connection conn =  DBUtil.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = "select * from foods where food_id = ?";
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, foodId);
			rs = st.executeQuery();
			if(rs.next()) {
				foodDTO = makeFoodDTO(rs);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		return foodDTO;
	}
	
	public List<FoodDTO> selectAllAvailableSharing(){
		List<FoodDTO> foodlist = new ArrayList<FoodDTO>();
		Connection conn =  DBUtil.getConnection();
		Statement st = null;
		ResultSet rs = null;
		String sql = """
					SELECT 
					    f.food_id,
					    f.giver_id,
					    f.name,
					    f.expiration_date,
					    f.registration_date,
					    f.place,
					    f.amount,
					    f.is_sharing
					FROM 
					    foods f
					JOIN 
					    users u ON f.giver_id = u.user_id
					LEFT JOIN (
					    SELECT 
					        food_id,
					        AVG(score) AS avg_score
					    FROM 
					        rating
					    GROUP BY 
					        food_id
					) r ON f.food_id = r.food_id
					where expiration_date >= sysdate and amount > 0 and is_sharing = 0 
					ORDER BY 
					    NVL(r.avg_score, 5) DESC,
					    f.registration_date DESC
					""";
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()) {
				FoodDTO foodDTO = makeFoodDTO(rs);
				foodlist.add(foodDTO);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		return foodlist;
	}
	
	public List<FoodDTO> selectAll(){
		List<FoodDTO> foodlist = new ArrayList<FoodDTO>();
		Connection conn =  DBUtil.getConnection();
		Statement st = null;
		ResultSet rs = null;
		String sql = """
					SELECT 
					    f.food_id,
					    f.giver_id,
					    f.name,
					    f.expiration_date,
					    f.registration_date,
					    f.place,
					    f.amount,
					    f.is_sharing
					FROM 
					    foods f
					JOIN 
					    users u ON f.giver_id = u.user_id
					LEFT JOIN (
					    SELECT 
					        food_id,
					        AVG(score) AS avg_score
					    FROM 
					        rating
					    GROUP BY 
					        food_id
					) r ON f.food_id = r.food_id
					ORDER BY 
					    NVL(r.avg_score, 5) DESC,
					    f.registration_date DESC
					""";
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()) {
				FoodDTO foodDTO = makeFoodDTO(rs);
				foodlist.add(foodDTO);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		return foodlist;
	}
	
	private FoodDTO makeFoodDTO(ResultSet rs) throws SQLException {
		FoodDTO foodDTO = FoodDTO.builder()
				.food_id(rs.getInt("food_id"))
				.giver_id(rs.getInt("giver_id"))
				.name(rs.getString("name"))
				.expiration_date(rs.getDate("expiration_date"))
				.registration_date(rs.getDate("registration_date"))
				.place(rs.getString("place"))
				.amount(rs.getInt("amount"))
				.is_sharing((rs.getInt("is_sharing") == 0))
				.build();
		return foodDTO;
	}

	public List<FoodDTO> getRecievedFoodList(UsersDTO user) {
		List<FoodDTO> foodlist = new ArrayList<FoodDTO>();
		Connection conn =  DBUtil.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = "select foods.* from foods join sharing on(foods.food_id = sharing.food_id) join users on(users.user_id = sharing.receiver_id) where users.user_id = ?";
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, user.getUser_id());
			rs = st.executeQuery();
			while(rs.next()) {
				FoodDTO foodDTO = makeFoodDTO(rs);
				foodlist.add(foodDTO);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		return foodlist;
	}
	
}
