package com.shinhan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.shinhan.dto.RatingDTO;
import com.shinhan.dto.UsersDTO;
import com.shinhan.utils.DBUtil;

public class RatingDAO {
	
	public int ratingDelete(int rating_id) {
		int result = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		String sql = """
					delete from rating where rating_id = ?
					""";
		
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, rating_id);
			result = st.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
		}
		
		return result;
	}
	
	public List<RatingDTO> selectById(UsersDTO user){
		List<RatingDTO> ratinglist = new ArrayList<>();
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = """
					select * from rating where writer_id = ?
					""";
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, user.getUser_id());
			rs = st.executeQuery();
			while(rs.next()) {
				RatingDTO ratingDTO = makeRatingDTO(rs);
				ratinglist.add(ratingDTO);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		
		return ratinglist;
	}
	
	public int ratingInsert(RatingDTO rating, int foodId, UsersDTO user) {
		int result = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		String sql = """
				insert into rating(
					WRITER_ID,
					FOOD_ID,
					SCORE,
					DAMAGE_CHECK,
					USER_COMMENT)
					values(?,?,?,?,?)
					""";
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, user.getUser_id());
			st.setInt(2, foodId);
			st.setInt(3, rating.getScore());
			st.setInt(4, rating.getDamage_check()?1:0);
			st.setString(5, rating.getUser_comment());
			result = st.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
		}
		
		return result;
	}
	
	
	
	private RatingDTO makeRatingDTO(ResultSet rs) throws SQLException {
		RatingDTO ratingDTO = RatingDTO.builder()
				.rating_id(rs.getInt("rating_id"))
				.writer_id(rs.getInt("writer_id"))
				.food_id(rs.getInt("food_id"))
				.score(rs.getInt("score"))
				.damage_check((rs.getInt("damage_check")==1))
				.user_comment(rs.getString("user_comment"))
				.build();
		return ratingDTO;
	}
}
