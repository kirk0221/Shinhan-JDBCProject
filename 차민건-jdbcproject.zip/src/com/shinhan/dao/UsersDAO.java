package com.shinhan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.shinhan.dto.UsersDTO;
import com.shinhan.utils.DBUtil;

public class UsersDAO {
	private UsersDTO makeUsersDTO(ResultSet rs) throws SQLException {
		UsersDTO usersDTO = UsersDTO.builder()
				.user_id(rs.getInt("user_id"))
				.id(rs.getString("id"))
				.password(rs.getString("password"))
				.name(rs.getString("name"))
				.phone_number(rs.getString("phone_number"))
				.address(rs.getString("address"))
				.is_vulnerable((rs.getInt("is_vulnerable") == 1))
				.point(rs.getInt("point"))
				.badge(rs.getString("badge"))
				.build();
		return usersDTO;
	}

	public int Membership_registration(UsersDTO user) {
		int result = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		String sql = """
				insert into users(
				 ID,
				 PASSWORD,
				 NAME,
				 PHONE_NUMBER,
				 ADDRESS,
				 IS_VULNERABLE,
				 POINT,
				 BADGE)
				 values(?,?,?,?,?,?,0,'없음')
				""";
		try {
			st = conn.prepareStatement(sql);
			st.setString(1, user.getId());
			st.setString(2, user.getPassword());
			st.setString(3, user.getName());
			st.setString(4, user.getPhone_number());
			st.setString(5, user.getAddress());
			st.setInt(6, (user.getIs_vulnerable()?1:0));
			result = st.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
		}
		return result;
	}

	public UsersDTO login(String id, String password) {
		UsersDTO user = null;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = """
					select * from users
					where id = ? and password = ?
					""";
		try {
			st = conn.prepareStatement(sql);
			st.setString(1, id);
			st.setString(2, password);
			rs = st.executeQuery();
			if(rs.next()) {
				user = makeUsersDTO(rs);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		
		return user;
	}
	
	public List<UsersDTO> selectToUserIdAndID(){
		List<UsersDTO> userlist = new ArrayList<>();
		Connection conn =  DBUtil.getConnection();
		Statement st = null;
		ResultSet rs = null;
		String sql = "select user_id, id from users";
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()) {
				UsersDTO usersDTO = UsersDTO.builder()
						.user_id(rs.getInt("user_id"))
						.id(rs.getString("id"))
						.build();
				userlist.add(usersDTO);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		return userlist;
	}
}
