package com.shinhan.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.shinhan.dto.SharingDTO;

public class SharingDAO {
	private SharingDTO makeSharingDTO(ResultSet rs) throws SQLException {
		SharingDTO sharingDTO = SharingDTO.builder()
				.sharing_id(rs.getInt("sharing_id"))
				.food_id(rs.getInt("food_id"))
				.receiver_id(rs.getInt("receiver_id"))
				.sharing_date(rs.getDate("sharing_date"))
				.build();
		return sharingDTO;
	}
}
