package com.shinhan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shinhan.dto.EmergencyRequestDTO;
import com.shinhan.dto.UsersDTO;
import com.shinhan.utils.DBUtil;

public class EmergencyRequestDAO {

	public int emergencyRequestDelete(int request_id) {
		int result = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		String sql = "delete from emergency_request where request_id = ?";
		
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, request_id);
			result = st.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
		}
		
		return result;
	}
	
	public int emergencyRequestUpdate(int request_id, EmergencyRequestDTO emergencyRequest) {
		int result = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		Map<String, Object> dynamicSQL = new HashMap<>();
		
		if(emergencyRequest.getFood_name()!=null) dynamicSQL.put("FOOD_NAME", emergencyRequest.getFood_name());
		if(emergencyRequest.getPlace()!=null) dynamicSQL.put("PLACE", emergencyRequest.getPlace());
		if(emergencyRequest.getDetail()!=null) dynamicSQL.put("DETAIL", emergencyRequest.getDetail());
		
		String sql = "update emergency_request set ";
		String sql2 = "where request_id = ?";
		int col = 1, colCount = dynamicSQL.size();
		for(String key: dynamicSQL.keySet()) {
			sql += key + "=" + "?" + (col!=colCount?",":"");
			col++;
		}
		sql += sql2;
		try {
			st = conn.prepareStatement(sql);
			int i=1;
			// 동적으로 값을 할당
			for(String key: dynamicSQL.keySet()) {
				st.setObject(i++, dynamicSQL.get(key));
			}
			st.setInt(i++, request_id);
			result = st.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
		}
		return result;
	}

	public int emergencyRequestInsert(UsersDTO user, EmergencyRequestDTO emergencyRequestDTO) {
		int result = 0;
		Connection conn = DBUtil.getConnection();
		PreparedStatement st = null;
		String sql = """
					insert into emergency_request(
					RECEIVER_ID,
					FOOD_NAME,
					PLACE,
					DETAIL
					)values(
					?,?,?,?
					)
					""";
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, user.getUser_id());
			st.setString(2, emergencyRequestDTO.getFood_name());
			st.setString(3, emergencyRequestDTO.getPlace());
			st.setString(4, emergencyRequestDTO.getDetail());
			result = st.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} finally {
			DBUtil.dbDisconnect(conn, st, null);
		}
		return result;
	}
	
	public List<EmergencyRequestDTO> selectByUserAddress(UsersDTO user){
		List<EmergencyRequestDTO> emergencyRequestlist = new ArrayList<EmergencyRequestDTO>();
		Connection conn =  DBUtil.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = "select * from emergency_request where place = ?";
		
		try {
			st = conn.prepareStatement(sql);
			st.setString(1, user.getAddress());
			rs = st.executeQuery();
			while(rs.next()) {
				EmergencyRequestDTO emergencyRequestDTO = makeEmergencyRequest(rs);
				emergencyRequestlist.add(emergencyRequestDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		
		return emergencyRequestlist;
	}
	
	public List<EmergencyRequestDTO> selectByUserId(UsersDTO user){
		List<EmergencyRequestDTO> emergencyRequestlist = new ArrayList<EmergencyRequestDTO>();
		Connection conn =  DBUtil.getConnection();
		PreparedStatement st = null;
		ResultSet rs = null;
		String sql = "select * from emergency_request where RECEIVER_ID = ?";
		
		try {
			st = conn.prepareStatement(sql);
			st.setInt(1, user.getUser_id());
			rs = st.executeQuery();
			while(rs.next()) {
				EmergencyRequestDTO emergencyRequestDTO = makeEmergencyRequest(rs);
				emergencyRequestlist.add(emergencyRequestDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		
		return emergencyRequestlist;
	}
	
	public  List<EmergencyRequestDTO> selectAll(){
		List<EmergencyRequestDTO> emergencyRequestlist = new ArrayList<EmergencyRequestDTO>();
		Connection conn =  DBUtil.getConnection();
		Statement st = null;
		ResultSet rs = null;
		String sql = "select * from emergency_request";
		
		try {
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()) {
				EmergencyRequestDTO emergencyRequestDTO = makeEmergencyRequest(rs);
				emergencyRequestlist.add(emergencyRequestDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.dbDisconnect(conn, st, rs);
		}
		
		return emergencyRequestlist;
	}

	private EmergencyRequestDTO makeEmergencyRequest(ResultSet rs) throws SQLException {
		EmergencyRequestDTO emergencyRequestDTO = EmergencyRequestDTO.builder()
				.request_id(rs.getInt("request_id"))
				.receiver_id(rs.getInt("receiver_id"))
				.food_name(rs.getString("food_name"))
				.place(rs.getString("place"))
				.detail(rs.getString("detail"))
				.request_date(rs.getDate("request_date"))
				.build();
		return emergencyRequestDTO;
	}
}
